3D  chess set 
====================

3D chess game done in HTML/CSS/JS.
Works only in webkit.

See it in action : http://codepen.io/juliangarnier/full/BsIih

**Libraries**

* Photon : http://photon.attasi.com
* Chess.js : https://github.com/jhlywa/chess.js


website - https://projectworlds.in

